package FinartzTest;

import static org.junit.Assert.assertEquals;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.io.File;
import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
public class TestMain {
	
      protected static String ChromePath = "drive\\\\chromedriver.exe";
      
     /* Chrome s�r�c�lerinize ula�mam�z� sa�lar.*/
     protected static ChromeDriverService service;
     /* Taray�c�y� kontrol eder. */
     protected static WebDriver driver;
     /* S�r�c�y� bekletmeye yarar. */
     protected static WebDriverWait wait;

     public static void main(String[] args) throws InterruptedException {
    	/* Taray�c� ve servisi ba�lat. */
        Setup();
        
        System.out.println("**************************PART-1*********************************");
        /* Finartz websitesine ba�lan */
        String baseUrl = "https://www.finartz.com/";
        String expectedTitle = "Finartz - Homepage";
        driver.get(baseUrl);
        
        /* Ba�lan�nca website ba�l���n� sakla */
        String actualTitle = driver.getTitle();
        
        /* Onaylama Fonksiyonlar� JUNIT */
        /* Sayfan�n a��ld��� onayla */
        assertEquals(actualTitle,expectedTitle);
        
        if (actualTitle.contentEquals(expectedTitle)){
            System.out.println("Finartz - Homepage A��ld�");
        } else {
            System.out.println("Finartz - Homepag A��lamad� !");
        }
        TimeUnit.SECONDS.sleep(2);
        
        System.out.println("**************************PART-2*********************************");
        String expectedTitle2 = "Solutions - Finartz";
        String solutionPageLink= driver.findElement(By.linkText("Solutions")).getAttribute("href");
        /* Solutions sayfas�na y�nlendir*/
        driver.get(solutionPageLink);
        
        /* Ba�lan�nca website ba�l���n� sakla */
        String actualTitle2 = driver.getTitle();
        
        /* Onaylama Fonksiyonlar� JUNIT */
        /* Sayfan�n a��ld��� onayla */
        assertEquals(actualTitle2,expectedTitle2);
 
        if (actualTitle2.contentEquals(expectedTitle2)){
            System.out.println("Solutions A��ld�");
        } else {
            System.out.println("Solutions A��lamad� !");
        }
        TimeUnit.SECONDS.sleep(2);
        
        System.out.println("**************************PART-3*********************************");
        List<WebElement> solutionTopic=driver.findElements(By.xpath("//h2[@class='title section-title has-text-centered dark-text']"));
        ArrayList<String> topicList=new ArrayList<String>();
        System.out.println("Finartz Innovative Solutions");
        for(WebElement element : solutionTopic) {
            System.out.println(element.getText());
            topicList.add(element.getText());
        }     
        TimeUnit.SECONDS.sleep(2);
        
        System.out.println("**************************PART-4*********************************");
        String expectedTitle3 = "Finartz";
        String blog= driver.findElement(By.linkText("Blog")).getAttribute("href");
        driver.get(blog);
        
        /* Ba�lan�nca website ba�l���n� sakla */
        String actualTitle3 = driver.getTitle();
        
        /* Onaylama Fonksiyonlar� JUNIT */
        /* Sayfan�n a��ld��� onayla */
        assertEquals(actualTitle3,expectedTitle3);
        if (actualTitle3.contentEquals(expectedTitle3)){
            System.out.println("Medium A��ld�");
        } else {
            System.out.println("Medium A��lamad� !");
        }
        TimeUnit.SECONDS.sleep(2);
        
        System.out.println("**************************PART-5*********************************");
        Random rand = new Random();
        /* 
         * 3. madde de 3 ana konu oldu�u i�in ve bunlar list yap�s�nda tutuldu�undan
         * 0 ile 2 aras�nda rastgele bir say� se�ilerek topicList de�i�keninde gerekli indeks'de
         * bulunan konu rastgele arat�l�r.
         */
        int select_rand_topic = rand.nextInt(2);
        WebElement txtSearch = driver.findElement(By.cssSelector("input[placeholder = 'Search Finartz']"));
        txtSearch.sendKeys(topicList.get(select_rand_topic));
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        
        String mediumSrc= driver.findElement(By.partialLinkText("Search for")).getAttribute("href");
        driver.get(mediumSrc);
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        String expectedTitle4 = "Search and find � Medium";
        String actualTitle4 = driver.getTitle();
        
        /* Onaylama Fonksiyonlar� JUNIT */
        /* Sayfan�n a��ld��� onayla */
        assertEquals(actualTitle4,expectedTitle4);
        if (actualTitle4.contentEquals(expectedTitle4)){
            System.out.println("Arama i�lemi ba�ar�l�");
        } else {
            System.out.println("Arama i�lemi ba�ar�s�z !");
        }
        TimeUnit.SECONDS.sleep(2);
        
        System.out.println("**************************PART-6*********************************");
        /* Taray�c� ve servisi durdur */
        Stop();
        System.out.println("Taray�c� ba�ar�l� �ekilde kapat�ld�...");
       
     }
     public static void Setup(){
    	    /* Chrome_driver.exe dizininden servisi olu�turur ve ba�lat�r. */
    	    service = new ChromeDriverService.Builder().
    	              usingDriverExecutable(new File(ChromePath)).
    	              usingAnyFreePort().
    	              build();
    	     try {
    	         service.start();
    	     } catch (Exception e) {
    	         e.printStackTrace();
    	     }
    	    
    	     System.setProperty("webdriver.chrome.driver", ChromePath);
    	     /* Driver nesnesini olu�turma */
    	     driver = new RemoteWebDriver(service.getUrl(),DesiredCapabilities.chrome());
    	     
    	     wait = new WebDriverWait(driver,15);

    	     driver.manage().window().maximize();
    }
     
    public static void Stop(){
         /* Taray�c�dan quit methodu ile ��k�� yap�l�r. */
         driver.quit();
         /* Stop methodu ile servis durdurulur */
         service.stop();
    }
    
}

